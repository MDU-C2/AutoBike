The matlab file can be used to run the simulation and plots are generated from there to do the desired comparisons. 
The plots show the x/y trajectory and all the states in time.

Select in line 31 which data you want to use for comparison.
In order to do relevant simulation, The velocity should be changed as well.

-------------
The x/y trajectory comparison with Yixiao's measurements data is not overlapping because of a different cooridinate system.
Yixiao was not sure how the coordinate system was defined. The coordinate system of the offline-kalman is defined as y-axis to north.